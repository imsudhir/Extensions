# JD PopX
[![Github All Releases](https://img.shields.io/github/downloads/joomdev/jd_popx/total.svg)](https://github.com/joomdev/jd_popx/releases)
![AUR](https://img.shields.io/aur/license/yaourt.svg)
[![GitHub release](https://img.shields.io/github/release/joomdev/jd_popx.svg)](https://github.com/joomdev/jd_popx/releases)
