DROP TABLE IF EXISTS `#__jdpopx_setting`;
