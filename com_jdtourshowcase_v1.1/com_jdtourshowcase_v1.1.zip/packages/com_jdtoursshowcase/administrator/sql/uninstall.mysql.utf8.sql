DROP TABLE IF EXISTS `#__jdtoursshowcase_tours`;
DROP TABLE IF EXISTS `#__jdtoursshowcase_tour_type`;
