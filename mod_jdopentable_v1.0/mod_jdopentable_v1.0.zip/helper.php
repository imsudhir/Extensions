<?php
// Licensed under the GPL v3
 /**
* Helper class for JD Open Table! module
* @package     JD Open Table 
* @copyright   Copyright (C) 2019 JoomDev, Inc. All rights reserved.
* @license     GNU General Public License version 2 or later; see LICENSE
*/

defined('_JEXEC') or die;
$doc = JFactory::getDocument();
//Style Sheet
$doc->addStyleSheet(JURI::root().'media/mod_jdopentable/css/jdopentable.css');
class modJdOpenTableHelper {
}