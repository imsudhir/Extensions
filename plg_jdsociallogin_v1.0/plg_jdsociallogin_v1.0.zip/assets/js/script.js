(function ($) {
	$(function () {
		// var Html ="";	
		//      Html += '<form  action="" method="get" id="" name="josForm" class="form-validate form-horizontal">';
		// 	  Html += '<div class="jd-button-control">';
		// 	  Html +=		'<button type="submit"  class="loginBtn loginBtn--facebook">Login</button>';
		// 	  Html +=	'<input type="hidden" value="sociallogin" name="plugin">';
		// 	 Html += 	'<input type="hidden" value="login" name="action">';
		// 	 Html += 	'<input type="hidden" value="facebook" name="provider">';
		// 	 Html += 	'</div>';
		// 	 Html += 	'</form>';


		// 	$("#form-login-password").append(Html);

	});
})(jQuery);


